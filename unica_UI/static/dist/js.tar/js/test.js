$('.card1').hide();
